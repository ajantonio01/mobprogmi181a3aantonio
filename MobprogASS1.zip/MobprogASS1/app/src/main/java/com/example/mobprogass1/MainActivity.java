package com.example.mobprogass1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button ConvertMilestoKm = (Button) findViewById(R.id.ConvertMilestoKm);
        ConvertMilestoKm.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                EditText textBoxKm = (EditText) findViewById(R.id.forKm);
                EditText textBoxMiles = (EditText) findViewById(R.id.forMiles);
                double vMiles = Double.valueOf(textBoxMiles.getText().toString());
                double vKm = vMiles / 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxKm.setText(formatVal.format(vKm));

            }
        });
        Button ConvertKmtoMiles = (Button) findViewById(R.id.ConvertKmtoMiles);
        ConvertKmtoMiles.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                EditText textBoxKm = (EditText) findViewById(R.id.forKm);
                EditText textBoxMiles = (EditText) findViewById(R.id.forMiles);
                double vKm = Double.valueOf(textBoxKm.getText().toString());
                double vMiles = vKm * 0.62137;
                DecimalFormat formatVal = new DecimalFormat("##.##");
                textBoxMiles.setText(formatVal.format(vMiles));
            }
        });
    }
}
